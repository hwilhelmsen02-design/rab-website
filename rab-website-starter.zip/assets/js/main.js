
(function(){
  const toggle = document.querySelector('.nav-toggle');
  const nav = document.getElementById('site-nav');
  if(toggle && nav){
    toggle.addEventListener('click', () => {
      const expanded = toggle.getAttribute('aria-expanded') === 'true';
      toggle.setAttribute('aria-expanded', String(!expanded));
      nav.classList.toggle('open');
    });
  }
  const y = document.getElementById('year');
  if(y){ y.textContent = String(new Date().getFullYear()); }

  const portalUrl = '#'; // TODO: replace with actual portal URL
  const l1 = document.getElementById('patient-portal-link');
  const l2 = document.getElementById('patient-portal-link-2');
  [l1,l2].forEach(el => { if(el){ el.href = portalUrl; el.rel = 'noopener'; el.target = '_blank'; }});

  const form = document.querySelector('form');
  if(form){
    form.addEventListener('submit', (e) => {
      const required = form.querySelectorAll('[required]');
      let ok = true;
      required.forEach(fld => {
        if(!fld.value.trim()){ ok = false; fld.setAttribute('aria-invalid','true'); fld.focus(); }
      });
      if(!ok){ e.preventDefault(); alert('Please complete all required fields.'); }
    });
  }

  if('serviceWorker' in navigator){
    navigator.serviceWorker.register('/sw.js').catch(console.error);
  }
})();
