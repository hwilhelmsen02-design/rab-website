
const CACHE = 'rab-cache-v1';
const ASSETS = [
  '/', '/index.html',
  '/providers.html','/services.html','/infusion.html','/patient-resources.html',
  '/insurance.html','/about.html','/contact.html','/privacy.html','/terms.html',
  '/assets/css/styles.css','/assets/js/main.js','/assets/img/logo.svg','/assets/img/favicon.svg'
];
self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(ASSETS)));
});
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k!==CACHE).map(k => caches.delete(k)))));
});
self.addEventListener('fetch', e => {
  const url = new URL(e.request.url);
  if (url.origin === location.origin){
    e.respondWith(caches.match(e.request).then(res => res || fetch(e.request)));
  }
});
